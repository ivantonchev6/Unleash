//
//  AnimatedBackground.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI

struct AnimatedBackground: View {
    let color1: Color
    let color2: Color
    @State private var animate: Bool = false

    var body: some View {
        LinearGradient(colors: [color1, color2], startPoint: animate ? .topLeading : .bottomLeading, endPoint: animate ? .bottomTrailing : .topTrailing)
            .ignoresSafeArea()
            .onAppear {
                withAnimation(.linear(duration: 10).repeatForever(autoreverses: true)) {
                    animate.toggle()
                }
            }
    }
}
