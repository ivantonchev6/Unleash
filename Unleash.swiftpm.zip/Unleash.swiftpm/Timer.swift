//
//  Timer.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI

struct TimerView: View {
    @Binding var seconds: Int
    @Binding var runTimer: Bool
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        VStack {
            Text(String(format: "%02d", seconds / 60) + ":" + String(format: "%02d", seconds % 60))
                .contentTransition(.numericText(countsDown: true))
                .onReceive(timer) { _ in
                    if seconds > 0 && runTimer {
                        withAnimation {
                            seconds -= 1
                        }
                        } else {
                        runTimer = false
                    }
                }
                .font(.system(size: 40))
                .bold()
        }
    }
}
