//
//  ERPMain.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI
import SwiftData

struct ERPMain: View {
    @Environment(\.modelContext) var modelContext
    @Query(sort: \Photo.intensity, animation: .easeOut) var photosQuery: [Photo]
    @Query(sort: \Word.intensity, animation: .easeOut) var wordsQuery: [Word]
    @State private var showPP: Bool = false
    @State private var showImageTherapy: Bool = false
    @State private var showWI: Bool = false
    @State private var showWordTherapy: Bool = false

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedBackground(color1: Color("DarkBlue"), color2: Color("LightGreen"))
                VStack {
                    if photosQuery.isEmpty && wordsQuery.isEmpty {
                        ContentUnavailableView("No resources", systemImage: "square.and.arrow.down", description: Text("Tap the \(Image(systemName: "plus")) button\n to add a photo or a word"))
                    } else {
                        VStack {
                            VStack {
                                if photosQuery.isEmpty {
                                    VStack {
                                        ScrollView(.horizontal, showsIndicators: false) {
                                            HStack {
                                                ForEach(wordsQuery) { word in
                                                    ZStack {
                                                        RoundedRectangle(cornerRadius: 35)
                                                            .foregroundStyle(.thinMaterial)
                                                        Text(word.word)
                                                            .padding(.horizontal)
                                                    }
                                                    .frame(height: 30)
                                                    .contextMenu {
                                                        Button("Delete") {
                                                            deleteWord(word)
                                                        }
                                                    }
                                                }
                                            }
                                            .padding()
                                        }
                                        Button {
                                            showWordTherapy.toggle()
                                        } label: {
                                            HStack {
                                                Text("Start ERP therapy with words")
                                                    .font(.title3)
                                                    .padding()
                                                Spacer()
                                                Image(systemName: "chevron.right")
                                                    .font(.title3)
                                                    .padding()
                                            }
                                            .background(.thinMaterial)
                                        }
                                    }
                                    .background(.ultraThinMaterial)
                                    .clipShape(RoundedRectangle(cornerRadius: 25))
                                    .padding()
                                    .fullScreenCover(isPresented: $showWordTherapy) {
                                        ERPWords(showView: $showWordTherapy)
                                    }
                                } else if wordsQuery.isEmpty {
                                    VStack {
                                        ScrollView(.horizontal, showsIndicators: false) {
                                            HStack {
                                                ForEach(photosQuery, id: \.photo) { image in
                                                    if let ready = UIImage(data: image.photo) {
                                                        Image(uiImage: ready)
                                                            .resizable()
                                                            .scaledToFit()
                                                            .frame(height: 190)
                                                            .clipShape(.rect(cornerRadius: 10))
                                                            .contextMenu {
                                                                Button("Delete") {
                                                                    deletePhoto(image)
                                                                }
                                                            }
                                                            .drawingGroup()
                                                    }
                                                }
                                            }
                                            .padding()
                                            .scrollTargetLayout()
                                        }
                                        .scrollTargetBehavior(.viewAligned)
                                        Button {
                                            showImageTherapy.toggle()
                                        } label: {
                                            HStack {
                                                Text("Start ERP therapy with photos")
                                                    .font(.title3)
                                                    .padding()
                                                Spacer()
                                                Image(systemName: "chevron.right")
                                                    .font(.title3)
                                                    .padding()
                                            }
                                            .background(.thinMaterial)
                                        }
                                    }
                                    .background(.ultraThinMaterial)
                                    .clipShape(RoundedRectangle(cornerRadius: 25))
                                    .padding()
                                    .fullScreenCover(isPresented: $showImageTherapy) {
                                        ERPPhotos(showView: $showImageTherapy)
                                    }
                                } else {
                                    VStack {
                                        ScrollView(.horizontal, showsIndicators: false) {
                                            HStack {
                                                ForEach(photosQuery, id: \.photo) { image in
                                                    if let ready = UIImage(data: image.photo) {
                                                        Image(uiImage: ready)
                                                            .resizable()
                                                            .scaledToFit()
                                                            .frame(height: 190)
                                                            .clipShape(.rect(cornerRadius: 10))
                                                            .contextMenu {
                                                                Button("Delete") {
                                                                    deletePhoto(image)
                                                                }
                                                            }
                                                            .drawingGroup()
                                                    }
                                                }
                                            }
                                            .padding()
                                            .scrollTargetLayout()
                                        }
                                        .scrollTargetBehavior(.viewAligned)
                                        Button {
                                            showImageTherapy.toggle()
                                        } label: {
                                            HStack {
                                                Text("Start ERP therapy with photos")
                                                    .font(.title3)
                                                    .padding()
                                                Spacer()
                                                Image(systemName: "chevron.right")
                                                    .font(.title3)
                                                    .padding()
                                            }
                                            .background(.thinMaterial)
                                        }
                                    }
                                    .background(.ultraThinMaterial)
                                    .clipShape(RoundedRectangle(cornerRadius: 25))
                                    .padding()
                                    .fullScreenCover(isPresented: $showImageTherapy) {
                                        ERPPhotos(showView: $showImageTherapy)
                                    }
                                    VStack {
                                        ScrollView(.horizontal, showsIndicators: false) {
                                            HStack {
                                                ForEach(wordsQuery) { word in
                                                    ZStack {
                                                        RoundedRectangle(cornerRadius: 35)
                                                            .foregroundStyle(.thinMaterial)
                                                        Text(word.word)
                                                            .padding(.horizontal)
                                                    }
                                                    .frame(height: 30)
                                                    .contextMenu {
                                                        Button("Delete") {
                                                            deleteWord(word)
                                                        }
                                                    }
                                                }
                                            }
                                            .padding()
                                            .scrollTargetLayout()
                                        }
                                        .scrollTargetBehavior(.viewAligned)
                                        Button {
                                            showWordTherapy.toggle()
                                        } label: {
                                            HStack {
                                                Text("Start ERP therapy with words")
                                                    .font(.title3)
                                                    .padding()
                                                Spacer()
                                                Image(systemName: "chevron.right")
                                                    .font(.title3)
                                                    .padding()
                                            }
                                            .background(.thinMaterial)
                                        }
                                    }
                                    .background(.ultraThinMaterial)
                                    .clipShape(RoundedRectangle(cornerRadius: 25))
                                    .padding()
                                    .fullScreenCover(isPresented: $showWordTherapy) {
                                        ERPWords(showView: $showWordTherapy)
                                    }
                                }
                                Spacer()
                            }
                            ZStack {
                                RoundedRectangle(cornerRadius: 25)
                                    .foregroundStyle(.ultraThinMaterial)
                                VStack(alignment: .leading, spacing: 10) {
                                    Text("Tips")
                                        .offset(CGSize(width: -20.0, height: -6.0))
                                        .bold()
                                        .font(.title3)
                                    Text(
"""
- Position yourself comfortably

- Take deep breths if you feel anxious

- Prepare to feel uncomfortable

- Move to a higher intensity element once you feel confident

- Do your best not to perform the compulsions

- Try to perform it for the selected minutes; if you can't bare it, tap on "Quick Exit"
"""
                                    )
                                    .font(.title3)
                                }
                            }
                            .frame(height: 370)
                            .padding()
                        }
                    }
                }
                .navigationTitle("ERP")
                .toolbar {
                    Menu {
                        Button {
                            showPP.toggle()
                        } label: {
                            Text("Photo")
                        }
                        Button {
                            showWI.toggle()
                        } label: {
                            Text("Word")
                        }
                    } label: {
                        Image(systemName: "plus")
                            .font(.title2)
                    }
                    .padding()
                }
                .sheet(isPresented: $showPP , content: {
                    PhotoPicker(showImageSheet: $showPP)
                })
                .sheet(isPresented: $showWI, content: {
                   WordPicker(showWordSheet: $showWI)
                })
            }
        }
    }
    func deletePhoto(_ photo: Photo) {
        modelContext.delete(photo)
    }
    func deleteWord(_ word: Word) {
        modelContext.delete(word)
    }
}
