//
//  MoodChart.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import Charts
import SwiftUI
import SwiftData

struct MoodChart: View {
    let moods: [String] = ["🤩", "😀", "🙂", "😐", "😕", "☹️", "😣"]
    @Environment(\.modelContext) var modelContext
    @Environment(\.presentationMode) var presentationMode
    @State private var selected = Time.week
    @Query var mood: [Mood]

    var body: some View {
        NavigationStack {
            VStack {
                List {
                    Section   {
                        Picker("Time", selection: $selected.animation()) {
                            Text("Week").tag(Time.week)
                            Text("Month").tag(Time.month)
                        } .pickerStyle(.segmented)
                    }
                    Section {
                        Chart {
                            ForEach(mood, id: \.dateCreated) { mood in
                                LineMark(x: .value("Day", mood.dateCreated, unit: .day), y: .value("Mood", mood.mood))
                                    .symbol(.circle)
                                    .interpolationMethod(.catmullRom)
                            }
                        }
                        .frame(height: 500)
                        .chartYScale(domain: moods)
                        .chartYAxis {
                            AxisMarks(position: .trailing)
                        }
                   .chartXAxis {
                        AxisMarks(values: .stride(by: .day)) { _ in
                            AxisGridLine()
                            AxisValueLabel(format: selected == .week ? .dateTime.weekday() : .dateTime.day())
                            }
                        }

                        .chartScrollTargetBehavior(
                            .valueAligned(
                                matching: .init(hour: 0),
                                majorAlignment: .matching(.init(day: 1))))
                        .chartScrollableAxes(.horizontal)
                        .chartXVisibleDomain(length: period(selected: selected))

                    }
                    Section {
                        NavigationLink {
                            List {
                                ForEach(mood, id: \.dateCreated) { data in
                                    LabeledContent("\(data.dateCreated.formatted(.dateTime.year().month().day().hour().minute()))") {
                                        Text(data.mood)
                                    }
                                }
                                .onDelete(perform: deleteMood)
                            }
                            .toolbar {
                                EditButton()
                            }
                        }label: {
                            Text("Show All Data")
                        }
                    }
                }
                .navigationTitle("Daily Mood Chart")
                .toolbarTitleDisplayMode(.inline)
                .toolbar {
                    Button {
                        self.presentationMode.wrappedValue.dismiss()
                    } label: {
                        Text("Close")
                    }
                }



            }
        }
    }

    func deleteMood(_ indexSet: IndexSet) {
        for index in indexSet {
            let mood = mood[index]
            modelContext.delete(mood)
        }
    }
    func period(selected: Time) -> Int {
        switch selected {
        case .week: 3600 * 24 * 7
        case .month: 3600 * 24 * 30
        }
    }
}

enum Time {
    case week, month
}
