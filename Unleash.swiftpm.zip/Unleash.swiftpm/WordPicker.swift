//
//  WordPicker.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI
import SwiftData

struct WordPicker: View {
    @Environment(\.modelContext) var modelContext
    @State private var word: String = ""
    @State private var wordIntensity: Int = 1
    @Binding var showWordSheet: Bool
    @State private var wordIsEmpty: Bool = false

    var body: some View {
        NavigationStack {
            VStack {
                List {
                    TextField(
                    "Enter a word",
                    text: $word
                    )
                    Section {
                        Picker("Intensity", selection: $wordIntensity) {
                            ForEach(1...10, id: \.self) { i in
                                Text("\(i)").tag(i)
                            }
                        }
                    } header: {
                        Text("Intensity")
                    }

                }
                .pickerStyle(.wheel)
            }.background(Color(.secondarySystemBackground))
                .navigationTitle("Enter a word or sentence")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    Button {
                        if word == "" {
                            wordIsEmpty = true
                        } else {
                            modelContext.insert(Word(word: word, intensity: wordIntensity))
                            showWordSheet.toggle()

                        }
                    } label: {
                        Text(word == "" ? "Close" : "Done")
                    }
                }
                .alert("No word entered", isPresented: $wordIsEmpty) {
                    Button("Enter", role: .cancel) { }
                    Button("Close", role: .destructive) { showWordSheet.toggle() }
                }
        }
    }
}
