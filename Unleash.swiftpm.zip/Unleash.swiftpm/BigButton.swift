//
//  BigButton.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI

struct BigButton: View {
    let heading: String
    let subheading: String
    let mainImage: String
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25.0)
                .foregroundStyle(.ultraThinMaterial)
                .shadow(radius: 4)
            HStack {
                Spacer()
                Image(systemName: mainImage)
                    .background {
                        Circle()
                            .foregroundStyle(.thinMaterial)
                            .frame(width: 80, height: 80)
                    }
                    .fontWeight(.light)
                    .foregroundStyle(.black)
                    .font(.system(size: 40))
                Spacer()
                VStack(alignment: .leading, spacing: 7) {
                    Text(heading)
                        .foregroundStyle(.black)
                        .font(.title2)
                        .bold()
                    Text(subheading)
                        .foregroundStyle(.black)

                }
                .frame(width: 120, height: 70)
                .padding(.trailing)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundStyle(.black)
                    .font(.system(size: 30))
                    .padding(.leading)
                Spacer()
            }
        }
        .frame(height: 150)
    }
}
