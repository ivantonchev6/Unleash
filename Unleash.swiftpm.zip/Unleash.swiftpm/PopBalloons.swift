//
//  PopBalloons.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI
import SpriteKit

class PopBalloons: SKScene, ObservableObject {
    let exitButtonAction: () -> Void
    @Published var gameState: GameState

    init(gameState: GameState, exitButtonAction: @escaping () -> Void) {
        self.gameState = gameState
        self.exitButtonAction = exitButtonAction
        super.init(size: UIScreen.main.bounds.size)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func didMove(to view: SKView) {
        let background = SKSpriteNode(imageNamed: "BalloonsBackground.jpeg")
        background.size = CGSize(width: frame.width, height: frame.height)
        background.position = CGPoint(x: frame.width / 2, y: frame.height / 2)
        addChild(background)
        run(SKAction.repeatForever(SKAction.sequence([SKAction.run(createBalloon), SKAction.wait(forDuration: 1.0)])))
    }

    func createBalloon() {
        let balloons: Array<SKSpriteNode> = [SKSpriteNode(imageNamed: "balloon.red.png"), SKSpriteNode(imageNamed: "balloon.blue.png"), SKSpriteNode(imageNamed: "balloon.purple.png"), SKSpriteNode(imageNamed: "balloon.brown.png"), SKSpriteNode(imageNamed: "balloon.black.png"), SKSpriteNode(imageNamed: "balloon.gray.png")]

        guard let balloon = balloons.randomElement() else { return }
        balloon.name = "balloon"

        balloon.position = CGPoint(x: CGFloat.random(in: 0...self.size.width), y: -balloon.size.height)

        if gameState.exit {
            exitButtonAction()
        }

        if gameState.score < gameState.balloonsForPop && !gameState.pause{
            addChild(balloon)
            let moveAction = SKAction.move(to: CGPoint(x: CGFloat.random(in: 0...self.size.width), y: size.height + balloon.size.height / 2), duration: 6.0)
            let removeAction = SKAction.removeFromParent()
            balloon.run(SKAction.sequence([moveAction, removeAction]))
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            let touchedNodes = nodes(at: location)

            if let balloonNode = touchedNodes.first(where: { $0.name == "balloon" }), let balloon = balloonNode as? SKSpriteNode, isTapValid(location: location, in: balloon) {
                let fadeOut = SKAction.fadeOut(withDuration: 0.5)
                let remove = SKAction.removeFromParent()
                balloonNode.run(SKAction.sequence([fadeOut, remove]))
                gameState.score += 1
            }
        }
    }

    func isTapValid(location: CGPoint, in node: SKSpriteNode) -> Bool {
        let threshold: CGFloat = 100.0
        let distance = sqrt(pow(location.x - node.position.x, 2) + pow(location.y - node.position.y, 2))

        return distance <= threshold
    }
}

struct SwiftUIView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @ObservedObject var gameState = GameState()
    @State private var balloonsToPop: Int = 20
    let numbersArray: [Int] = [10, 20, 30]
    @State private var showSheet: Bool = false

    var scene: SKScene {
        let scene = PopBalloons(gameState: gameState) {
            self.presentationMode.wrappedValue.dismiss()
        }
        scene.size = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        scene.scaleMode = .fill
        scene.anchorPoint = CGPoint(x: 0, y: 0)
        return scene
    }

    var body: some View {
        ZStack {
            SpriteView(scene: scene)
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                .ignoresSafeArea()
                .navigationBarBackButtonHidden()
            Buttons(gameState: gameState)
        }
        .onAppear {
                showSheet.toggle()
            gameState.exit = false
            gameState.score = 0
            }
        .sheet(isPresented: $showSheet, content: {
            NavigationStack {
                ZStack {
                    Color(red: 0.6, green: 0.8, blue: 0.9   )
                    VStack{
                        Spacer()
                        Text("Pop the Balloons")
                            .font(.system(size: 60))
                        Spacer()
                        Image(systemName: "balloon")
                            .font(.system(size: 100))
                        Spacer()

                        Picker("Select the amount of balloons to pop in order to win the game", selection: $balloonsToPop) {
                            ForEach(numbersArray, id: \.self) { number in
                                Text("\(number)")
                            }
                        }
                        .pickerStyle(.segmented)
                        .frame(width: 500)
                        .padding(.bottom, 30)

                        Button {
                            showSheet.toggle()
                            gameState.balloonsForPop = balloonsToPop
                            gameState.pause = false
                        } label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                    .frame(width: 500,height: 60)
                                    .foregroundStyle(.blue)
                                Text("Start the Game")
                                    .foregroundStyle(.white)
                                    .bold()
                            }
                        }

                        Spacer()
                    }
                }
            }
        })
    }
}

struct Buttons: View {
    @State private var isShownWin: Bool = true
    @State private var isShownPaused: Bool = false
    @ObservedObject var gameState: GameState

    var body: some View {
        if gameState.score == gameState.balloonsForPop {
            PausedOrWin(isShown: $isShownWin, type: .win, gameState: gameState)
                .frame(width: 700, height: 900)
                .clipShape(RoundedRectangle(cornerRadius: 25.0))
        } else {
            VStack {
                HStack {
                    Spacer()
                    Button {
                        isShownPaused.toggle()
                        gameState.pause.toggle()
                    } label: {
                        Image(systemName: "pause.circle")
                            .foregroundStyle(.black)
                            .font(.system(size: 60))
                    }
                    .padding(30)
                    .sheet(isPresented: $isShownPaused, onDismiss: { gameState.pause.toggle() }, content: {
                        PausedOrWin(isShown: $isShownPaused, type: .pause, gameState: gameState)
                    })
                }
                .ignoresSafeArea()
                Spacer()
            }
        }
    }
}

struct PausedOrWin: View {
    @Binding var isShown: Bool
    @State var type: SheetView
    @ObservedObject var gameState: GameState

    var body: some View {
        ZStack {
            Color(red: 0.6, green: 0.8, blue: 0.9   )
            VStack {
                Spacer()
                Text(type == .win ? "Game Won" : "Paused")
                    .font(.system(size: 70))
                    .foregroundStyle(.black)
                if type == .pause {
                    Text("Current score: \(gameState.score)")
                        .foregroundStyle(.black)
                        .font(.title)
                        .padding(.top)
                } else {
                    Text("🥳")
                        .font(.system(size: 60))
                        .padding(.top)
                }
                Spacer()
                HStack {
                    Spacer()
                    Button {
                        gameState.exit.toggle()
                    } label: {
                        VStack {
                            Image(systemName: "rectangle.portrait.and.arrow.forward")
                                .font(.system(size: 60))
                                .foregroundStyle(.black)
                            Text("Exit")
                                .foregroundStyle(.black)
                                .font(.title)
                                .padding(.top)
                        }
                    }
                    Spacer()
                    Button {
                        if type == .win {
                            gameState.score = 0
                        } else if type == .pause {
                            isShown.toggle()
                        }
                    } label: {
                        VStack{
                            Image(systemName: type == .win ? "restart.circle" : "play.circle")
                                .font(.system(size: 60))
                                .foregroundStyle(.black)

                            Text(type == .win ? "Play Again" : "Continue")
                                .foregroundStyle(.black)
                                .font(.title)
                                .padding(.top)
                        }
                    }
                    Spacer()
                }
                Spacer()
            }
        }
    }
}

enum SheetView {
    case win
    case pause
}

class GameState: ObservableObject {
    @Published var balloonsForPop = 20
    @Published var score = 0
    @Published var pause = true
    @Published var exit = false
}
