//
//  Math.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI

struct Math: View {
    @State private var currentLevel: Int = 2
    private let amountOfQuestions: [Int] = [10, 20, 30]
    @State private var selectedAmountOfQuestions: Int = 10
    @State private var answer: Int = 0
    @State private var questions = [Question]()
    @State private var isShowing: Bool = false
    @State private var isShowing1: Bool = false
    @State private var questionsHolder = Question(question: "", answer: 0)
    @State private var score: Int = 0

    var body: some View {
        ZStack {
            AnimatedBackground(color1: Color("LightBlue"), color2: Color("LightYellow"))
            VStack {
                Section {
                    Picker("Select number of questions", selection: $selectedAmountOfQuestions) {
                        ForEach(amountOfQuestions, id: \.self) { number in
                            Text("\(number)")
                        }
                    }
                    .pickerStyle(.segmented)
                    .padding()
                } header: {
                    Text("Select the number of questions")
                        .padding()
                        .font(.headline)
                }
                Section {
                    Text("How much is: \(questionsHolder.question)")
                        .font(.system(size: 20))
                        .bold()
                        .padding()
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .frame(height: 40)
                            .foregroundStyle(.white)
                        TextField("Enter your answer here...", value: $answer, format: .number)
                            .padding()
                            .keyboardType(.decimalPad)
                            .onSubmit {
                                if questions.isEmpty {
                                    isShowing1 = true
                                } else if answer != questionsHolder.answer {
                                    isShowing = true
                                } else {
                                    buttionAction()
                                }
                            }
                    }
                    .padding()
                    Text("If the result is not natural, you have to round it to the lower value")
                        .font(.caption)
                        .padding()
                    Text("If the numbers are big, try to solve the equation on a sheet of paper")
                        .font(.caption)
                }
                Spacer()
            }
            .frame(width: UIScreen.main.bounds.width * (8/10), height: 800)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .shadow(radius: 10)
        }
        .alert("Wrong", isPresented: $isShowing) {
            Button("Continue", action: buttionAction)
        } message: {
            Text("The correct answer is \(questionsHolder.answer)")
        }
        .alert("Questions finished", isPresented: $isShowing1) {
            Button("Start new game", action: reset)
        } message: {
            Text("You got \(score) of \(selectedAmountOfQuestions) correct!")
        }
        .onAppear(perform: startGame)
        .onChange(of: currentLevel, startGame)
        .onChange(of: selectedAmountOfQuestions, startGame)
    }

    func buttionAction() {
        if questionsHolder.answer == answer {
            score += 1
        }
        answer = 0
        if questions.isEmpty {
            isShowing1 = true
            questionsHolder = Question(question: "", answer: 0)
        } else {
            questions.remove(at: 0)
        }

        if questions.isEmpty {
            isShowing1 = true
            questionsHolder = Question(question: "", answer: 0)
        } else {
            questionsHolder = questions[0]
        }
    }

    func startGame() {
        questionsHolder = Question(question: "", answer: 0)
        questions.removeAll()
        generateQuestions()
        questionsHolder = questions[0]
    }

    func reset() {
        score = 0
        answer = 0
        startGame()
    }
    func squareRoot() -> (Int, Int) {
        let number = [1, 4, 9, 16, 25, 26, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256].randomElement()
        return (Int(sqrt(Double(number ?? 1))), number ?? 1)
    }
    func divide() -> (Int, (Int, Int)) {
        let first = Int.random(in: 1...100)
        let second = Int.random(in: 1...first)
        return (first / second, (first, second))
    }

    func generateQuestions() {
        for _ in 0..<selectedAmountOfQuestions {
            let symbol = ["/", "*", "+", "-", "^", "√"].randomElement()
            var text: String = ""
            var answer: Int = 0
            switch symbol {
            case "/":
                let d: (Int, (Int, Int)) = divide()
                answer = d.0
                text = "\(d.1.0) / \(d.1.1)"
            case "*":
                let first = Int.random(in: 1...100)
                let second = Int.random(in: 1...100)
                answer = first * second
                text = "\(first) * \(second)"
            case "+":
                let first = Int.random(in: 1...100)
                let second = Int.random(in: 1...100)
                answer = first + second
                text = "\(first) + \(second)"
            case "-":
                let first = Int.random(in: 1...100)
                let second = Int.random(in: 1...100)
                answer = first - second
                text = "\(first) - \(second)"
            case "^":
                let first = Int.random(in: 1...100)
                let second = Int.random(in: 1...3)
                answer = Int(pow(Double(first), Double(second)))
                text = "\(first) to the power of \(second)"
            case "√":
                let s: (Int, Int) = squareRoot()
                answer = s.0
                text = "√\(s.1)"
            default : answer = 0
                text = "Error"
            }
            questions.append(Question(question: text, answer: answer))
        }
    }
}

struct Question {
    var question: String
    var answer: Int
}
