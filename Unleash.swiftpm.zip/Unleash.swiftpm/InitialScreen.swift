//
//  InitialScreen.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI

struct InitialScreen: View {
    @Environment(\.dismiss) var dismiss
    var body: some View {
        VStack {
            Spacer()
            Image("AppIconImage")
                .resizable()
                .scaledToFit()
                .clipShape(.rect(cornerRadius: 25))
                .frame(width: 150, height: 150)
                .padding()
            Text("Welcome to Unleash")
                .font(.largeTitle)
                .bold()
                .padding()
            Text("A first of its kind app, containing some of the most helpful features for treating OCD")
                .font(.subheadline)
                .padding(.bottom, 30)
            VStack(alignment: .leading) {
                HStack {
                    Image(systemName: "face.smiling")
                        .foregroundStyle(.yellow)
                        .font(.largeTitle)
                    Text("**Mood Tracker**\nThe integrated mood tracker helps you analyze your mood over a period of time and whether the ERP therapy has a positive effect on you.")
                }
                .padding()
                HStack {
                    Image(systemName: "brain.filled.head.profile")
                        .foregroundStyle(.pink)
                        .font(.largeTitle)
                    Text("**ERP**\nConsidered the \"magic treatment,\" Exposure and Response Prevention therapy has proved itslef to be the best way to treat OCD; however it's painfully hard and requires strong will.")
                }
                .padding()
                HStack {
                    Image(systemName: "figure.mind.and.body")
                        .foregroundStyle(.mint)
                        .font(.largeTitle)
                    Text("**Mindfulness**\nTake a brief breathing session, which can help reduce anxiety.")
                }
                .padding()
            }
            .padding(.horizontal, 15)
            Spacer()
            Spacer()
            Button {
                UserDefaults.standard.set(true, forKey: "hasBeenLaunched")
                dismiss()
            } label: {
                ZStack {
                    RoundedRectangle(cornerRadius: 25.0)
                    Text("Continue")
                        .foregroundStyle(.white)
                        .font(.headline)
                }
            }
            .foregroundStyle(.cyan)
            .frame(width: 400, height: 70)
       Spacer()
        }
    }
}
