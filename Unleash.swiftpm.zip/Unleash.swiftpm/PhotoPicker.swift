//
//  PhotoPicker.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI
import SwiftData
import PhotosUI

struct PhotoPicker: View {
    @Environment(\.modelContext) var modelContext
    @State private var photo: Data?
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var imageIntensity: Int = 1
    @State private var photoIsEmpty: Bool = false
    @Binding var showImageSheet: Bool

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("Intensity", selection: $imageIntensity) {
                        ForEach(1...10, id: \.self) { i in
                            Text("\(i)").tag(i)
                        }
                    }.pickerStyle(.wheel)
                } header: {
                    Text("Intensity")
                }
            }
            PhotosPicker("Choose a photo", selection: $selectedPhoto, matching: .images).photosPickerStyle(.compact)

                .toolbar {
                    Button {
                        if selectedPhoto == nil {
                            photoIsEmpty.toggle()
                        } else {
                            Task {
                                if let image = try? await selectedPhoto?.loadTransferable(type: Data.self) {
                                    photo = image
                                    saveIg()
                                }
                            }
                            showImageSheet.toggle()
                        }
                    } label: {
                        Text(selectedPhoto == nil ? "Close" : "Done")
                    }
                    .alert("No photo selected", isPresented: $photoIsEmpty) {
                        Button("Select", role: .cancel) {}
                        Button("Cancel", role: .destructive) { showImageSheet.toggle() }

                    }
                }
                .navigationTitle("Select intensity")
                .navigationBarTitleDisplayMode(.inline)

        }
    }
    func saveIg() {
        guard let finalImage = photo else {
            print("Error unwrapping")
            return
        }
        modelContext.insert(Photo(photo: finalImage, intensity: imageIntensity))
        selectedPhoto = nil
    }
}
