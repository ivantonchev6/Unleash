//
//  BalloonsSelector.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI

struct BalloonsSelector: View {
    let arrayOfNumbers: [Int] = [10, 20 ,30]
    @Binding var balloonsToPop: Int
    var closeSheetAndOpenGame: () -> Void
    @State private var gameState = GameState()

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.6, green: 0.8, blue: 0.9   )
                VStack{
                    Spacer()
                    Text("Pop the Balloons")
                        .font(.system(size: 60))
                    Spacer()
                    Image(systemName: "balloon")
                        .font(.system(size: 100))
                    Spacer()

                    Picker("Select the amount of balloons to pop in order to win the game", selection: $balloonsToPop) {
                        ForEach(arrayOfNumbers, id: \.self) { number in
                            Text("\(number)")
                        }
                    }
                    .pickerStyle(.segmented)
                    .frame(width: 500)
                    .padding(.bottom, 30)

                    Button {
                        closeSheetAndOpenGame()
                    } label: {
                        ZStack {
                            RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                .frame(width: 500,height: 60)
                            Text("Start the Game")
                                .foregroundStyle(.white)
                                .bold()
                        }
                    }

                    Spacer()
                }
            }
        }
    }
}
