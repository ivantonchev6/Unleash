//
//  ERPPhotos.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI
import SwiftData

struct ERPPhotos: View {
    @Environment(\.modelContext) var modelContext
    @Query(sort: \Photo.intensity) var photos: [Photo]
    @State private var photosL = [(UIImage, UIColor)]()
    @Binding var showView: Bool
    @State private var selected: Int = 0
    @State private var runTimer: Bool = false
    @State private var started: Bool = false
    @State private var seconds: Int = 60
    @State private var selectedMinutes: Int = 0
    let minutes: [Int] = [60, 300, 600, 900, 1200, 1800]

    var body: some View {
        NavigationStack {
            VStack {
                Spacer()
                TimerView(seconds: $seconds, runTimer: $runTimer)
                Spacer()
                if photosL.isEmpty {
                    ProgressView()
                } else {
                    Image(uiImage: photosL[selected].0)
                        .resizable()
                        .scaledToFit()
                        .clipShape(.rect(cornerRadius: 25))
                        .frame(width: UIScreen.main.bounds.width * (2/3), height: 600)

                }
                Spacer()
                Spacer()
                Picker("Minutes", selection: $seconds) {
                    ForEach(minutes, id: \.self) { period in
                        Text("^[\(period / 60) minute](inflect: true)")
                    }
                }.pickerStyle(.segmented)
                    .padding(.horizontal, 60)
                    .padding(.bottom, 60)
                    .opacity(started ? 0 : 1)
                Button {
                    withAnimation {
                        action()
                    }
                } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: UIScreen.main.bounds.width * (1/3), height: 60)
                        Text("\(textPicker())")
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    .padding(.bottom, 60)
                }
                .opacity(!showButton() ? 0 : 1)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background {
            if photosL.isEmpty {
                ProgressView()
            } else {
                withAnimation {
                    Color(photosL[selected].1)
                }
            }
        }
        .ignoresSafeArea()
        .onAppear {
            for photo in photos {
                if let ready = UIImage(data: photo.photo) {
                    if let averageColor = ready.averageColor {
                        let imageColor = (ready, averageColor)
                        photosL.append(imageColor)
                    }
                }
            }
        }
        .toolbar {
            Button {
                showView.toggle()
            } label: {
                Text("Quick Exit")
            }
        }
        }
    }
    func textPicker() -> String {
        if started == false {
            return "Start"
        } else if seconds > 0 {
            return "Higher intensity image"
        } else {
            return "Exit"
        }
    }
    func action() {
        if started == false {
            runTimer.toggle()
            started.toggle()
        } else if seconds > 0 {
            selected += 1
        } else {
            showView.toggle()
        }
    }
    func showButton() -> Bool {
        if started == false {
            return true
        } else if selected < photos.count - 1 {
            return true
        } else if seconds == 0{
            return true
        } else {
           return false
        }
    }
}
