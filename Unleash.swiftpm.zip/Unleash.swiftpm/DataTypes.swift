//
//  DataTypes.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI
import SwiftData

@Model
class Mood {
    let mood: String
    let dateCreated: Date

    init(mood: String, date: Date) {
        self.mood = mood
        self.dateCreated = date
    }
}

@Model
class Photo {
    @Attribute(.externalStorage)  let photo: Data
    let intensity: Int

    init(photo: Data, intensity: Int) {
        self.photo = photo
        self.intensity = intensity
    }
}

@Model
class Word{
    let word: String
    let intensity: Int
    init(word: String, intensity: Int) {
        self.word = word
        self.intensity = intensity
    }
}

