//
//  ERPWords.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI
import SwiftData

struct ERPWords: View {
    @Environment(\.modelContext) var modelContext
    @Query(sort: \Word.intensity) var words: [Word]
    @Binding var showView: Bool
    @State private var runTimer: Bool = false
    @State private var started: Bool = false
    @State private var selected: Int = 0
    @State private var seconds: Int = 60
    @State private var selectedMinutes: Int = 0
    let minutes: [Int] = [60, 300, 600, 900, 1200, 1800]

    var body: some View {
        NavigationStack {
            VStack {
                Spacer()
                TimerView(seconds: $seconds, runTimer: $runTimer)
                Spacer()
                VStack {
                    ForEach(1...10, id: \.self) { _ in
                        HStack {
                            ForEach(1...7, id: \.self) { _ in
                                ZStack {
                                    RoundedRectangle(cornerRadius: 35)
                                        .foregroundStyle(Color(.lightGray).opacity(0.2))
                                    Text(words[selected].word)
                                        .font(.system(size: CGFloat(Int.random(in: 10...50))))
                                        .bold(Bool.random())
                                }
                                .frame(width: CGFloat(words[selected].word.count * 30), height: 50)
                                .padding(4)
                            }
                        }
                    }
                }
                Spacer()
                Spacer()
                Picker("Minutes", selection: $seconds) {
                    ForEach(minutes, id: \.self) { period in
                        Text("^[\(period / 60) minute](inflect: true)")
                    }
                }.pickerStyle(.segmented)
                    .padding(.horizontal, 60)
                    .padding(.bottom, 60)
                    .opacity(started ? 0 : 1)
                Button {
                    withAnimation {
                    action()
                    }
                } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width: UIScreen.main.bounds.width * (1/3), height: 60)
                        Text(textPicker())
                            .foregroundStyle(.white)
                            .font(.headline)
                    }
                    .padding(.bottom, 60)
                }
                .opacity(!showButton() ? 0 : 1)
            }
            .toolbar {
                Button {
                    showView.toggle()
                } label: {
                    Text("Quick Exit")
                }
            }
            .background(Color("DarkGreen"))
        }
        }
    func textPicker() -> String {
        if started == false {
            return "Start"
        } else if seconds > 0 {
            return "Higher intensity word"
        } else {
            return "Exit"
        }
    }
    func action() {
        if started == false {
            runTimer.toggle()
            started.toggle()
        } else if seconds > 0 {
            selected += 1
        } else {
            showView.toggle()
        }
    }
    func showButton() -> Bool {
        if started == false {
            return true
        } else if selected < words.count - 1 {
            return true
        } else if seconds == 0{
            return true
        } else {
           return false
        }
    }
}
