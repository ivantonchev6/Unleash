import Charts
import SwiftUI
import SwiftData

struct ContentView: View {
    @State private var showWelcome: Bool = !UserDefaults.standard.bool(forKey: "hasBeenLaunched")
    @State private var moodValue: Double = 0.475
    @Environment(\.modelContext) var modelContext
    @State private var showMoodChart: Bool = false
    @State private var showMindfulness: Bool = false
    @State private var moodLogged: Bool = false

    var body: some View {
        NavigationStack {
            ZStack {
                AnimatedBackground(color1: Color("DarkBlue"), color2: Color("DarkGreen"))
                ScrollView(showsIndicators: false) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 30)
                            .frame(height: 570)
                            .padding()
                            .foregroundStyle(.ultraThinMaterial)
                        if moodLogged {
                            VStack {
                                Image(systemName: "checkmark.circle")
                                    .font(.system(size: 60))
                                    .foregroundStyle(.gray)
                                    .padding(.bottom)
                                Text("Done")
                                    .font(.title)
                                    .foregroundStyle(.gray)

                            }
                            .frame(height: 510)
                            .task {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                    withAnimation {
                                        moodLogged.toggle()
                                    }
                                }
                            }
                        } else {
                            HStack(spacing: 40) {
                                VStack {
                                    Text("Log Your Mood")
                                        .font(.title)
                                        .fontWeight(.medium)
                                        .padding(.top, 30)
                                    Spacer()
                                    Text(emoji(value: moodValue))
                                        .font(.system(size: 100))
                                        .animation (
                                            .easeOut(duration: 0.7),
                                            value: moodValue
                                        )
                                        .drawingGroup()
                                        .glow(color: .yellow, radius: 30, opacity: moodValue)
                                    Spacer()
                                    Spacer()
                                    Slider(value: $moodValue, in: 0.3...0.65) {

                                    } minimumValueLabel: {
                                        Image("face.frowning")
                                            .font(.title3)
                                    }maximumValueLabel: {
                                        Image(systemName: "face.smiling")
                                            .font(.title3)
                                    }
                                    .tint(.yellow)
                                    .padding()
                                    Button {
                                        logFeeling()
                                        withAnimation {
                                            moodLogged.toggle()
                                        }
                                    } label: {
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 40.0)
                                                .frame(width: (UIScreen.main.bounds.width / 2.7), height: 40)
                                            Text("Log")
                                                .foregroundStyle(.white)
                                                .bold()
                                        }
                                        .padding(.top)
                                        .padding(.horizontal)
                                        .padding(.bottom, 25)
                                    }
                                }
                                .frame(width: UIScreen.main.bounds.width / 2.4)
                                .background(.ultraThinMaterial)
                                .clipShape(RoundedRectangle(cornerRadius: 25))
                                .shadow(radius: 4)
                                VStack {
                                    Button {
                                        showMoodChart.toggle()
                                    } label: {
                                        BigButton(heading: "Daily Mood", subheading: "See chart", mainImage: "face.smiling")
                                    }.sheet(isPresented: $showMoodChart, content: {
                                        MoodChart()
                                    })
                                    .padding(.bottom)
                                    Divider()
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 25)
                                            .foregroundStyle(.ultraThinMaterial)
                                            .shadow(radius: 4)
                                        VStack(alignment: .center) {
                                            Spacer()
                                            Spacer()
                                            ZStack {
                                                Circle()
                                                    .frame(width: 100, height: 100)
                                                    .foregroundStyle(.thinMaterial)
                                                Image(systemName: "leaf")
                                                    .font(.system(size: 50))
                                            }
                                            Spacer()
                                            Spacer()
                                            VStack(alignment: .center) {
                                                Text("Mindfulness")
                                                    .font(.title2)
                                                    .bold()
                                                    .padding(.bottom, 1.0)

                                                Text("Begin a relaxing breathing session to improve your mood")

                                            }
                                            .padding(.horizontal)
                                            NavigationLink {
                                                Mindfulness()
                                            } label: {
                                                ZStack {
                                                    RoundedRectangle(cornerRadius: 40.0)
                                                        .frame(width: UIScreen.main.bounds.width / 3 ,height: 40)
                                                    Text("Start")
                                                        .foregroundStyle(.white)
                                                        .bold()

                                                }
                                                .padding(.vertical)
                                            }
                                            Spacer()
                                        }
                                    }
                                    .padding(.top)
                                }
                                .frame(width: UIScreen.main.bounds.width / 2.4)
                            }
                            .frame(height: 510)
                        }
                    }
                    Grid {
                        GridRow {
                            GridElement(title: "Understanding OCD",
                                           subtitle: "Learning about OCD and its biology can alleviate your symptoms",
                                           buttonText: "Helpful Information",
                                           destination: OCDInformation(),
                                           imageName: "book.pages")

                            GridElement(title: "Popping Balloons",
                                           subtitle: "Imagine destroying your intrusive thoughts while popping balloons",
                                           buttonText: "Pop the Balloons",
                                           destination: SwiftUIView(),
                                           imageName: "balloon")
                        }
                        GridRow {
                            GridElement(title: "Math",
                                           subtitle: "Calculating math problems fast can help you mitigate the obsessions",
                                           buttonText: "Solve the problem",
                                           destination: Math(),
                                           imageName: "x.squareroot")
                            GridElement(title: "ERP",
                                           subtitle: "Write things that trigger compulsions and try not to do them",
                                           buttonText: "Start ERP",
                                           destination: ERPMain(),
                                           imageName: "exclamationmark.triangle")
                        }
                    }
                }
                .padding(.horizontal)
            }
            .navigationTitle("Unleash")
            .sheet(isPresented: $showWelcome) {
                InitialScreen()
            }
        }
    }
    func logFeeling() {
        modelContext.insert(Mood(mood: emoji(value: moodValue), date: Date.now))
    }
    func emoji(value: Double) -> String {
        switch value {
        case 0.3...0.35: "😣"
        case 0.35...0.4: "☹️"
        case 0.4...0.45: "😕"
        case 0.45...0.5: "😐"
        case 0.5...0.55: "🙂"
        case 0.55...0.6: "😀"
        case 0.6...0.65: "🤩"
        default: ""
        }
    }
}
