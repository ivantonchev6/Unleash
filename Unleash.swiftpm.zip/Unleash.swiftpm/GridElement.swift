//
//  GridElement.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI

struct GridElement<Content: View>: View {
    let title: String
    let subtitle: String
    let buttonText: String
    let destination: Content
    let imageName: String

    init(title: String, subtitle: String, buttonText: String, destination:  Content, imageName: String) {
        self.title = title
        self.subtitle = subtitle
        self.buttonText = buttonText
        self.destination = destination
        self.imageName = imageName
    }
    var body: some View {
        ZStack{
            RoundedRectangle(cornerRadius: 30)
                .frame(height: 340)
                .foregroundStyle(.ultraThinMaterial)
                .padding()
            VStack(alignment: .center) {
                Spacer()
                Spacer()
                Spacer()
                ZStack {
                    Circle()
                        .frame(width: 110, height: 110)
                        .foregroundStyle(.thinMaterial)
                    Image(systemName: imageName)
                        .font(.system(size: 60))
                }
                Spacer()
                Spacer()
                VStack(alignment: .center) {
                    Text(title)
                        .font(.title2)
                        .bold()
                        .padding(.bottom, 1.0)

                    Text(subtitle)

                }
                .padding(.horizontal)

                    NavigationLink(destination: destination) {
                        ZStack {
                            RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                .frame(width: 340,height: 60)
                            Text(buttonText)
                                .foregroundStyle(.white)
                                .bold()

                        }
                    .padding()
                }

                Spacer()
                Spacer()
            }
            .padding()
        }
    }
}
