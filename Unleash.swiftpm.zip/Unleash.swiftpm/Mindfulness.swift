//
//  Mindfulness.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI

struct Mindfulness: View {
    @Environment(\.dismiss) var dismiss
    @State private var initiateSession: Bool = false
    @State private var showView: Bool = false
    @State private var timerCount: CGFloat = 0
    @State private var animationAmount: Int = 0
    @State private var animationDo: Int = 1
    @State private var button: Bool = true

    var body: some View {
        NavigationStack {
            ZStack {
                Color("MindfulnessBackground")
                VStack {
                    Spacer()
                    ZStack {
                        ForEach(1...6, id: \.self) { item in
                            Circle()
                                .fill(LinearGradient(colors: [Color("Cyan"), Color("LighterGreen")], startPoint: .trailing, endPoint: .leading).opacity(0.5))
                                .frame(width: 150, height: 150)
                                .offset(x: initiateSession ? 75 : 0)
                                .rotationEffect(.init(degrees: Double(item) * 60))
                                .rotationEffect(.init(degrees: initiateSession ? 0 : -60))
                                .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
                        }
                        .scaleEffect(initiateSession ? 1 : 0.6)
                    }
                    .onReceive(Timer.publish(every: 0.01, on: .main, in: .common).autoconnect()) { _ in
                        if showView {
                            if timerCount > 4.2 {
                                timerCount = 0
                                withAnimation(.easeInOut(duration: 4).delay(0.1)) {
                                    initiateSession.toggle()
                                }
                                withAnimation {
                                    animationAmount += 1
                                }
                                if animationAmount >= ((animationDo * 7) * 2) {
                                    showView = false
                                }
                            } else {
                                timerCount += 0.01
                            }
                        } else {
                            timerCount = 0
                        }
                    }
                    Spacer()
                    Text(text())
                        .animation(.easeInOut(duration: 1), value: animationAmount)
                        .foregroundStyle(.gray)
                        .font(.title2)
                    ZStack {
                        RoundedRectangle(cornerRadius: 25)
                            .foregroundStyle(.ultraThinMaterial)
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Tips")
                                .offset(CGSize(width: -20, height: -6))
                                .bold()
                            Text("Sit and position yourself comfortably.")
                            Text("Enhance your experience by placing one of your hand on the chest and the other on the stomach.")
                            Text("Take deep breaths and concentrate on how the air moves through the lungs.")
                        }
                    }
                    .frame(width: UIScreen.main.bounds.width * (2.5/3), height: 150)
                    .opacity(button ? 1 : 0)
                    .animation(.easeOut, value: button)
                    Spacer()
                    Button {
                        action()
                    } label: {
                        RoundedRectangle(cornerRadius: 25)
                            .frame(width: 400, height: 80)
                            .overlay {
                                Text(buttonText())
                                    .font(.headline)
                                    .foregroundStyle(.white)
                            }
                    }.padding(.bottom, 60)
                        .opacity(visible() ? 1 : 0)
                        .animation(.easeOut, value: button)
                }
            }
            .toolbar {
                Picker("Minuntes", selection: $animationDo) {
                    ForEach(1...5, id: \.self) { n in
                        Text("^[\(n) minute](inflect: true)").tag(n)
                    }
                } .pickerStyle(.menu)
                    .opacity(button ? 1 : 0)
                    .animation(.easeOut, value: button)
            }
            .ignoresSafeArea()
        }
    }

    func text() -> String {
        if animationAmount == 1 {
            return "Stay still and pay attention to your breathing"
        } else if animationAmount == 2 {
            return "Inhale..."
        } else if animationAmount == 3 {
            return "exhale"
        } else if animationAmount == ((animationDo * 7) * 2) {
            return "Well done!"
        }
        return " "
    }
    func buttonText() -> String {
        if animationAmount == 0 {
            return "Start"
        } else {
            return "Exit"
        }
    }
    func action() {
        if animationAmount == 0 {
            showView.toggle()
            withAnimation(.easeInOut(duration: 4).delay(0.1)) {
                initiateSession = true
                button.toggle()
            }
        } else {
            dismiss()
        }
    }
    func visible() -> Bool {
        if button {
            return true
        } else if animationAmount == ((animationDo * 7) * 2) {
            return true
        } else {
            return false
        }
    }
}
