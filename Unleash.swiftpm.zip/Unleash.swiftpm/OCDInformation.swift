//
//  OCDInformation.swift
//  Unleash
//
//  Created by Ivan Tonchev on 24.02.24.
//

import SwiftUI

struct OCDInformation: View {
    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading) {
                    Text("What is OCD?")
                        .padding()
                        .font(.title)
                        .bold()
                    Text(
    """
            Obsessive-compulsive disorder (OCD) is a mental health condition equally affecting men, women, and children of all races and ethnicities. The usual onset is during adolescence. It occurs in approximately 1 in 100 individuals. People with OCD suffer from obsessions accompanied by compulsions, which can seriously impair general function.

            Obsessions are persistent thoughts, images, or urges that cause significant distress (e.g. fears of contamination, excessive worry about responsibility, perfectionism, or disturbing thoughts of a moral nature). Most individuals realize that these obsessions are illogical and don’t want them but feel unable to regain control; that is due to a disruption in the brain’s ability to filter thoughts and perceive threats. Examples of obsessions are:

                        - Fear of contamination
                        - Excessive worry about responsibility
                        - Perfectionism
                        - Disturbing thought of moral nature

            Compulsions are repetitive behavior one feels compelled to perform to lessen the anxiety caused by obsessions (neutralize the obsession). These ‘rituals’ are a temporary solution that only makes matters worse. Performing compulsions consumes invaluable time, leaving the individual debilitated and unable to deal with daily tasks. Common compulsions include:

                        - Excessive washing/cleaning
                        - Checking
                        - Repeating actions a given number of times
                        - Mental acts

            The causes of OCD are yet unknown. Researchers believe that the main ones are genetics and environment. Major contributors to developing the disorder are traumatic events during childhood.


            Albeit OCD is a chronic disease, there are ways to treat it and even recover completely. The first approach is Cognitive Behavioral Therapy, especially ERP, which is aimed at helping patients confront their fears and resist compulsions. The second, not preferable, one is medications like selective serotonin reuptake inhibitors. However, they can only help reduce the severity of the symptoms and not treat it fully.

            Living with obsessive-compulsive disorder is challenging and everyone who has it needs strong support as well as understanding that can improve their living quality and ensure a fulfilling life.
    """
                    )
                    .padding(.horizontal)
                    Text("The biology of OCD")
                        .padding()
                        .font(.title)
                        .bold()
                    Text(
                        """
**Introduction**

            The biology of obsessive-compulsive disorder refers to the mechanism of OCD. Neuroanatomical studies implicate the prefrontal cortex, basal ganglia, insula, and posterior cingulate cortex. Neurochemical studies implicate glutamate (amino acid responsible for the synthesis of proteins) and monoamine neurotransmitters, in particular serotonin and dopamine.

**Neuroanatomical**

            Obsessions usually arise from the failure of the cortico-basal ganglia-thalamo-cortical loop (a system of neural circuits in the brain) to dispatch information that is typically implicitly processed. This causes explicit processing in systems like the dlPFC (a part of the prefrontal cortex, responsible for executive functions such as planning, temporary memory, and reasoning) and the hippocampus (responsible for converting short-term memories into long-term ones).

            The dysfunction in the mOFC (again a part of the prefrontal cortex involved in decision-making), ventral striatum (a component of the motor and reward systems), and amygdala (plays a major in the processing of memory, decision making, and emotional responses, including fear and anxiety) contributes to exaggerated anxiety and emotional responses in individuals with OCD. This is reflected in heightened responses to fearful stimuli and reduced reactions to positive stimuli.

            Additionally, the ventral striatum is responsible for action selection and receives inputs from the OFC that indicate the possible outcome of a stimulus. The input might be abnormal and lead to compulsive behavior by altering the selected action.

            Besides abnormal input, compulsions may result from error monitoring dysfunction, thus leading to excessive uncertainty.

            Another concept suggests that OCD results from dysfunction in response inhibition and fear extinction, driven by the hyperactivation of brain regions such as the amygdala, prefrontal cortex, and hippocampus. This hyperactivity contributes to generating obsessions that are inadequately regulated by the mOFC.

            Sometimes obsessions derive from compulsions because of habituation and association of certain activities with a thought.

**Neurochemical**

            Serotonin, the most influential neurotransmitter in OCD, is utilized by nerve cells for communication. It plays a crucial role in regulating various functions, including mood, emotions, memory, and sleep. Individuals with OCD often exhibit low levels of serotonin, emphasizing its significance in the development and manifestation of the disorder.

            Glutamate is implicated in OCD, with low levels observed in the striatum and high levels in the ACC (anterior cingulate cortex - involved in high-level functions like attention allocation, reward anticipation, decision-making, emotion, and impulse control). This neurotransmitter's role in attention allocation, reward anticipation, decision-making, emotion, and impulse control underscores its significance in influencing OCD behaviors.

            People with obsessive-compulsive disorder reportedly exhibit reduced dopamine (neurotransmitter, component of the reward-motivated behavior) receptors and transporters in the striatum.

            Low estrogen levels can also increase OCD behaviors.
"""
                    )
                    .padding(.horizontal)
                    Text("Tips")
                        .padding()
                        .font(.title)
                        .bold()
                    Text(
    """
            Talk to a medical health professional to obtain a proper diagnosis and treatment. You must follow their advice!

            Begin a CPT should you be advised to do so.

            Get to know the disorder; this helps with the realization that everything is just in your brain

            Read “Brain Lock” written by Dr. Jeffrey Schwartz; a wonderful book dedicated to obsessive-compulsive disorder

            Follow this helpful self-treatment method mentioned in the book: The Four-Step Self-Treatment Method. The four steps are as follows:

                        - Relabel - recognize the thoughts as OCD and don’t take them seriously
                        - Reattribute - acknowledge that the obsessions’ presence is due to a chemical imbalance in the brain
                        - Refocus - allocate your attention to doing beneficial activities
                        - Revalue - realize that the thoughts are “useless garbage” as he says in the book

            Just do what you enjoy!😉
"""
                    )
                    .padding(.horizontal)
                    Divider()
                        .padding()
                    Text("Information acqired from:")
                        .bold()
                        .italic()
                        .padding(.bottom, 4)
                        .padding(.horizontal)
                    Link("Wikipedia: Obsessive-compulsive disorder", destination: URL(string: "https://en.wikipedia.org/wiki/Obsessive–compulsive_disorder")!)
                        .padding(.horizontal)
                        .foregroundStyle(.link)
                    Link("Wikipedia: Biology of obsessive-compulsive disorder", destination: URL(string: "https://en.m.wikipedia.org/wiki/Biology_of_obsessive–compulsive_disorder")!)
                        .padding(.horizontal)
                        .foregroundStyle(.link)
                }
            }
            .background(Color(.secondarySystemBackground).ignoresSafeArea())
            .navigationTitle("Article")
        }
    }
}
